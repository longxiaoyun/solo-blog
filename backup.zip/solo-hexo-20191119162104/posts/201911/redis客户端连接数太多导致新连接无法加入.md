title: redis客户端连接数太多导致新连接无法加入
date: '2019-11-19 16:19:16'
updated: '2019-11-19 16:19:16'
tags: [Redis]
permalink: /articles/2019/11/19/1574151556247.html
---
![](https://img.hacpai.com/bing/20190512.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)




今天重启了下项目，发现日志里报错redis除了故障，可是明明redis正常启动着，却连接不上，怀疑是不是并发数太高导致的(单击redis，并未做集群)


```shell
redis.exceptions.ConnectionError: Error 99 connecting to 10.9.129.36:6379. Cannot assign requested address
```




于是查看redis连接数 

`redis-cli info | grep connected`


``` shell
connected_clients:4226
    
connected_slaves:0
```

居然有4000多 ，

可以看看有哪些客户端连接了，以及具体信息
```shell
$  redis-cli
> client list 
```


截取部分信息如下
```shell
    # id  客户端标识id
    # addr 客户端地址
    # fd socket的文件描述符，与lsof命令结果中的fd是同一个，如果fd=-1代表当前客户端不是外部客户端，而是Redis内部的伪装客户端
    # name 客户端名字
    # age 已经连接的时间
    # idle 连接空闲时间(s),age等于idle说明该客户端一直空闲
    # flags 客户端 flag
    # db 客户端连接的redis db
    # sub  已订阅频道的数量
    # psub 已订阅模式的数量
    # multi 在事务中被执行的命令数量
    # gbuf 查询缓冲区的长度（字节为单位， 0 表示没有分配查询缓冲区）
    # qbuf-free 查询缓冲区剩余空间的长度（字节为单位， 0 表示没有剩余空间）
    # obl 输出缓冲区的长度（字节为单位， 0 表示没有分配输出缓冲区）
    # oll 输出列表包含的对象数量（当输出缓冲区没有剩余空间时，命令回复会以字符串对象的形式被入队到这个队列里）
    # omem 输出缓冲区和输出列表占用的内存总量
    # events 文件描述符事件
    # cmd 最近一次执行的命令
    id=5660094459 addr=10.9.148.14:33228 fd=1387 name= age=1831688 idle=1831688 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660094460 addr=10.9.148.14:33230 fd=1388 name= age=1831688 idle=1831688 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660094461 addr=10.9.148.14:33232 fd=1389 name= age=1831688 idle=1831688 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660094462 addr=10.9.148.14:33234 fd=1390 name= age=1831688 idle=1831688 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660094463 addr=10.9.148.14:33236 fd=1391 name= age=1831688 idle=1831688 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660094464 addr=10.9.148.14:33238 fd=1392 name= age=1831688 idle=1831688 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660094465 addr=10.9.148.14:33240 fd=1393 name= age=1831688 idle=1831688 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660093515 addr=10.9.148.14:60590 fd=957 name= age=1831689 idle=1831689 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660093516 addr=10.9.148.14:60592 fd=958 name= age=1831689 idle=1831689 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660095824 addr=10.9.148.14:34418 fd=1980 name= age=1831686 idle=1831686 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660095825 addr=10.9.148.14:34420 fd=1981 name= age=1831686 idle=1831686 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
    id=5660095827 addr=10.9.148.14:34422 fd=1983 name= age=1831686 idle=1831686 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=expire
```
可以看出，我的这么多客户端几乎都处于空闲状态，典型的占着那啥，其实原因感觉还是没有设置还过期时间

，连接池维护了这么多的连接，却都是空闲的，难怪新连接连不上了。设置下超时时间
```shell
    $ redis-cli
    > CONFIG SET timeout 30
```


然后再看一下客户端连接数
```shell
redis-cli info | grep connected

connected_clients:425
connected_slaves:0
```
以下就降到了400多，新连接页可以连上了,在看每个哭护短连接的情况，基本都正常了
```shell
    $ redis-cli
    > client list
    
    id=6768852389 addr=10.9.154.230:52148 fd=31 name= age=215 idle=25 flags=N db=3 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=hget
    id=6768852392 addr=10.9.154.230:52158 fd=32 name= age=215 idle=25 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=hincrby
    id=6768882063 addr=10.9.79.96:50144 fd=114 name= age=155 idle=20 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=hincrby
    id=6768986365 addr=10.9.145.108:46426 fd=257 name= age=50 idle=25 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=hincrby
    id=6768639705 addr=10.9.122.6:33504 fd=147 name= age=524 idle=22 flags=N db=3 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=hget
    id=6768898591 addr=10.9.17.153:58560 fd=210 name= age=138 idle=16 flags=N db=4 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=hincrby
    id=6768648695 addr=10.9.145.108:34298 fd=125 name= age=513 idle=16 flags=N db=3 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=hget
    id=6768710012 addr=10.9.145.108:52828 fd=230 name= age=417 idle=6 flags=N db=3 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=hget
    id=6768684916 addr=10.9.38.183:39054 fd=135 name= age=468 idle=25 flags=N db=3 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=hget
    id=6756656068 addr=10.9.154.230:56406 fd=209 name= age=12064 idle=4 flags=N db=0 sub=0 psub=0 multi=-1 qbuf=0 qbuf-free=0 obl=0 oll=0 omem=0 events=r cmd=zcard
```




[参考] [https://www.runoob.com/redis/server-client-list.html](https://www.runoob.com/redis/server-client-list.html)

