title: 我在 GitHub 上的开源项目
date: '2019-11-19 15:39:59'
updated: '2019-11-19 15:39:59'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [sina_weibo_login](https://github.com/longxiaoyun/sina_weibo_login) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`3`](https://github.com/longxiaoyun/sina_weibo_login/watchers "关注数")&nbsp;&nbsp;[⭐️`6`](https://github.com/longxiaoyun/sina_weibo_login/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/longxiaoyun/sina_weibo_login/network/members "分叉数")</span>

wap端新浪微博自动登录，自动滑动解锁



---

### 2. [comment-word-cloud](https://github.com/longxiaoyun/comment-word-cloud) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/longxiaoyun/comment-word-cloud/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/longxiaoyun/comment-word-cloud/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/longxiaoyun/comment-word-cloud/network/members "分叉数")</span>





---

### 3. [movie-star](https://github.com/longxiaoyun/movie-star) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/longxiaoyun/movie-star/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/longxiaoyun/movie-star/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/longxiaoyun/movie-star/network/members "分叉数")</span>

电影《摆渡人》评分饼状图



---

### 4. [doubancomments](https://github.com/longxiaoyun/doubancomments) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/longxiaoyun/doubancomments/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/longxiaoyun/doubancomments/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/longxiaoyun/doubancomments/network/members "分叉数")</span>





---

### 5. [FaceRecognition](https://github.com/longxiaoyun/FaceRecognition) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/longxiaoyun/FaceRecognition/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/longxiaoyun/FaceRecognition/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/longxiaoyun/FaceRecognition/network/members "分叉数")</span>

A part of FaceApp



---

### 6. [MessageUI](https://github.com/longxiaoyun/MessageUI) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/longxiaoyun/MessageUI/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/longxiaoyun/MessageUI/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/longxiaoyun/MessageUI/network/members "分叉数")</span>

vue  chat 组件



---

### 7. [autohome](https://github.com/longxiaoyun/autohome) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/longxiaoyun/autohome/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/longxiaoyun/autohome/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/longxiaoyun/autohome/network/members "分叉数")</span>





---

### 8. [-Logo](https://github.com/longxiaoyun/-Logo) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/longxiaoyun/-Logo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/longxiaoyun/-Logo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/longxiaoyun/-Logo/network/members "分叉数")</span>

爬取汽车Logo



---

### 9. [iNKi](https://github.com/longxiaoyun/iNKi) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/longxiaoyun/iNKi/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/longxiaoyun/iNKi/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/longxiaoyun/iNKi/network/members "分叉数")</span>

react-native-learn



---

### 10. [scrapy-lianjia](https://github.com/longxiaoyun/scrapy-lianjia) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/longxiaoyun/scrapy-lianjia/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/longxiaoyun/scrapy-lianjia/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/longxiaoyun/scrapy-lianjia/network/members "分叉数")</span>

爬取链家二手房数据

