title: python3正则提取ip
date: '2019-08-21 17:24:52'
updated: '2019-08-21 17:24:52'
tags: [笔记, python]
permalink: /articles/2019/11/19/1574152493847.html
---
找到一个免费代理，返回的代理ip用正则提取，简单记下
```
url="http://www.89ip.cn/tqdl.html?api=1&num=30&port=&address=&isp="

r=requests.get(url,timeout=45)

print(r.text)

content='''
<a href="http://www.qydaili.com/" target="_blank" data-type="img"><img src="img/hgg.png"></a><br><script type="text/javascript" src="js/jquery.min.js"></script>
<div id="adarea"onclick=location.href='http://www.qydaili.com/' style="cursor: pointer;display: none;position: fixed;right:15px;bottom:15px;width: 285px;height: 250px;background: url(/img/fkgg.png) no-repeat;">
<div id="adclose" style="cursor: pointer; position: absolute;  top: 0px;  right: 0px;  display: block;  width: 20px;  height: 20px;font-family: cursive;background: url(img/close.png) no-repeat;" title="点击关闭"> </div>
</div>
<script type="text/javascript">
$(function(){
$('#adarea').slideDown(500);
$('#adclose').click(function(){
$('#adarea').slideUp(500);
});
});1.1.1.1:11
</script>
186.148.168.94:33019<br>144.217.229.154:1080<br>46.246.63.56:8118<br>60.13.42.201:9999<br>103.194.249.167:8080<br>180.94.64.114:8080<br>190.186.89.150:35759<br>194.186.173.6:54842<br>105.235.214.66:8080<br>81.163.113.192:8080<br>103.124.12.145:8080<br>203.81.93.193:8080<br>36.90.252.212:8080<br>183.146.29.237:8888<br>51.68.215.137:8080<br>182.255.61.159:3128<br>47.95.10.105:3128<br>35.237.212.225:80<br>41.170.12.92:37444<br>1.198.72.250:9999<br>177.135.228.3:53281<br>185.105.101.142:5220<br>200.60.79.11:53281<br>112.85.130.56:9999<br>46.48.149.254:8080<br>114.141.52.11:80<br>191.98.198.45:34504<br>118.70.185.14:8080<br>5.9.142.124:3128<br>188.128.87.218:8080<br>高效高匿名代理IP提取地址：http://www.qydaili.com/
'''
```

不校验ip(格式)有效性
```
l=re.findall(r'\d+\.\d+\.\d+\.\d+:\d+',content)

print(l)
print(len(l))
```

校验(格式)有效性
```
n=re.findall(r'(?:2[0-5][0-5]\.|[0-1]?\d?\d+\.){3}(?:2[0-5][0-5]|[0-1]{0,1}\d?\d+):\d+',content)

print("==%s" % n)
print(len(n))
```

其中
```
# 一般ip的格式(0-255).(0-255).(0-255).(0-255),所以  [0-1]{0,1}\d?\d?  是说要么是0开头，要么是1开头，十位数匹配零次或一次(可有可无)，个位数匹配零次或一次(可有可无)
# (?:n) 表示所匹配到的n不输出
# \d?表示匹配前面的子表达式零次或一次,等价于 {0,1}
# + 表示匹配前面的表达式一次或多次
```
