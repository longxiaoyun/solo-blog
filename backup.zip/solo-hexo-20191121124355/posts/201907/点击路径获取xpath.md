title: 点击路径获取xpath
date: '2019-07-09 11:09:18'
updated: '2019-07-09 11:09:18'
tags: [javascript]
permalink: /articles/2019/11/19/1574152746345.html
---
Click element  get  xpath 
在一个html页面，通过点击某处元素，可以获取到该点击元素的xpath,这样可以不用再用代码来一个一个的写，Google浏览器右键有copy  xpath的功能，也有很多浏览器插件可以实现，这里看一下怎么在代码里通过js来获取。
### 一.鼠标事件，框选目标元素
#### 1.鼠标经过，框选目标元素
```html
<!DOCTYPE html>
<html>
<head>
	<title>点击获取xpath路径</title>
</head>
<body>
	<div id="box">
		<table class="text">
			<thead>
				<p>哈哈哈哈哈哈</p>
			</thead>
			<tbody>
				<tr>
					<td>张三</td>
					<td>男</td>
				</tr>
				<tr>
					<td>李四</td>
					<td>男</td>
				</tr>
				<tr>
					<td>王五</td>
					<td>女</td>
				</tr>
				<tr>
					<td>陈六</td>
					<td>男</td>
				</tr>
				<tr>
					<td>张奇</td>
					<td>男</td>
				</tr>
				<tr>
					<td>tom</td>
					<td>男</td>
				</tr>
				<tr>
					<td>jerry</td>
					<td>男</td>
				</tr>
			</tbody>
		</table>
	</div>
	<a href="wwww.baidu.com">去百度</a>
	<a href="www.longxyun.com">去其他</a>

</body>
<script>
(function() {
  var prev;

  if (document.body.addEventListener) {
    document.body.addEventListener('mouseover', handler, false);
  }
  else if (document.body.attachEvent) {
    document.body.attachEvent('mouseover', function(e) {
      return handler(e || window.event);
    });
  }
  else {
    document.body.onmouseover = handler;
  }

  function handler(event) {
    if (event.target === document.body ||
        (prev && prev === event.target)) {
      return;
    }
    if (prev) {
      prev.className = prev.className.replace(/\bbh\b/, '');
      prev = undefined;
    }
    if (event.target) {
      prev = event.target;
      prev.className += "bh";
    }
  }


})();




</script>
<style type="text/css">
	.bh {
		border:1px dashed #000;
	}
</style>

</html>
```
#### 2.鼠标点击，框选目标元素
```html
<!DOCTYPE html>
<html>
<head>
	<title>点击获取xpath路径</title>
</head>
<body>
	<div id="box">
		<table class="text">
			<thead>
				<p>哈哈哈哈哈哈</p>
			</thead>
			<tbody>
				<tr>
					<td>张三</td>
					<td>男</td>
				</tr>
				<tr>
					<td>李四</td>
					<td>男</td>
				</tr>
				<tr>
					<td>王五</td>
					<td>女</td>
				</tr>
				<tr>
					<td>陈六</td>
					<td>男</td>
				</tr>
				<tr>
					<td>张奇</td>
					<td>男</td>
				</tr>
				<tr>
					<td>tom</td>
					<td>男</td>
				</tr>
				<tr>
					<td>jerry</td>
					<td>男</td>
				</tr>
			</tbody>
		</table>
	</div>
	<a href="wwww.baidu.com">去百度</a>
	<a href="www.longxyun.com">去其他</a>

</body>
<script>
(function() {
  var prev;

  if (document.body.addEventListener) {
    document.body.addEventListener('click', handler, false);
  }
  else if (document.body.attachEvent) {
    document.body.attachEvent('click', function(e) {
      return handler(e || window.event);
    });
  }
  else {
    document.body.onclick=handler
  }

  function handler(event) {
    if (event.target === document.body ||
        (prev && prev === event.target)) {
      return;
    }
    // 组织click点击事件
    event.preventDefault();
    if (event.target) {
      prev = event.target;
      prev.className += "bh";
    }
  }


})();

</script>
<style type="text/css">
	.bh {
		border:1px dashed #000;
	}
</style>

</html>
```

### 二.监听点击事件，点击获取目标元素xpath
找到一个工具，可以很好的实现以需要
[jXpath](https://gitee.com/chenkj/jXpath) 
```html
<!DOCTYPE html>
<html>
<head>
	<title>点击获取xpath路径</title>
</head>
<body>
	<div id="box">
		<table class="text">
			<thead>
				<p>哈哈哈哈哈哈</p>
			</thead>
			<tbody>
				<tr>
					<td>张三</td>
					<td>男</td>
				</tr>
				<tr>
					<td>李四</td>
					<td>男</td>
				</tr>
				<tr>
					<td>王五</td>
					<td>女</td>
				</tr>
				<tr>
					<td>陈六</td>
					<td>男</td>
				</tr>
				<tr>
					<td>张奇</td>
					<td>男</td>
				</tr>
				<tr>
					<td>tom</td>
					<td>男</td>
				</tr>
				<tr>
					<td>jerry</td>
					<td>男</td>
				</tr>
			</tbody>
		</table>
	</div>
	<a href="wwww.baidu.com">去百度</a>
	<a href="www.longxyun.com">去其他</a>

</body>
<script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.1.0/jquery.js"></script>
<script type="text/javascript" src="jQueryGetXpath.js"></script>
<script>
    $(function () {
	$('body *').unbind("click");
        $('body *').click(function () {
            var path = $(this).jQueryGetXpath("getXpath", { mode: 'id_class' });
            alert(path);
            console.log(path);
            return false;
        });
    });

</script>
</html>

```
