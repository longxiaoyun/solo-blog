title: ' jenkins发布springboot和vue项目'
date: '2019-06-18 18:17:15'
updated: '2019-06-18 18:17:15'
tags: [jenkins, java]
permalink: /articles/2019/11/19/1574152854851.html
---
> 项目采用了前后端分离的模式，后端使用springboot，前端用vue,通过jenkins结合coding进行

**jenkins安装**

现在war包，放到tomcat的webapps下，启动tomcat，访问 http://ip:8080/jenkins 即可，具体设置可见[官方文档](官方文档) 

**后端发布**

后端打包成jar包，然后可以直接java -jar xxxxxx.jar,因为前后端分离了，所以我就没用war包，具体方法是

coding+jenkins+springboot后端

**环境配置**

我只有一台机器，所以jenkins和待发布到的目标机器都是一个，首先配置下机器的环境，用到jdk,maven,git都安装一下，这些也可以在jenkins中自动安装，我这里手动在系统安装了，完了配置下路径

(Ps：JDK8下载需要登录orcle帐号)

在jenkins的 系统管理->全局工具配置，配置jdk,maven,git和nodejs(nodejs使用了自动安装，为了少踩点坑，我这里的版本和开发环境一致)






然后 安装将需要的jenkins插件，系统管理 ->插件管理

Git plugin,Maven Integration plugin,NodeJS Plugin




接下来可以新建项目了

新建项目 ->构建一个Maven项目，输入项目名，确定；然后进入项目->配置





这里的WebHook要再coding里配置一下,进入coding的项目管理，项目->设置->WebHook->新建WebHook,填入上图的链接




**build**


然后在post steps 中输入脚本


```shell
#!/bin/bash
BUILD_ID=valkyrie
JARFILE=/root/local/valkyrie-server/valkyrie.jar
BACKFILE=/root/local/valkyrie-server/backup/valkyrie-$(date +%Y%m%d).jar

#关掉上次启动的项目
ps -ef | grep $JARFILE | grep -v grep | awk '{print $2}' | xargs kill -9
echo "关闭旧服务"

#复制执行文件
cp target/valkyrie-0.0.1-SNAPSHOT.jar $JARFILE
#备份执行文件
cp target/valkyrie-0.0.1-SNAPSHOT.jar $BACKFILE

#启动
java -jar $JARFILE & > /root/local/valkyrie-server/log.file 2>&1 &
echo "发布完成"
exit 0

```

到这，后台基本发布完成

**前端**
新建项目->构建一个自由风格的软件项目


进入项目配置页面
同样，这里连接到git和构建触发器和后端相似，在构建环境中，需要填入我们刚刚配置的nodejs环境


然后构建，执行shell```shell
#!/bin/bash
node -v
npm install -g yarn --registry=https://registry.npm.taobao.org

npm install
npm run build:prod

cd dist

rm -rf valkyrie-ui.tar.gz
tar -zcvf valkyrie-ui.tar.gz *

mv valkyrie-ui.tar.gz /root/local/valkyrie-ui/valkyrie-ui.tar.gz
cd /root/longjiang/valkyrie-ui
tar -zxvf valkyrie-ui.tar.gz
rm valkyrie-ui.tar.gz
```
注意执行之前先建立响应的文件夹
前端发布完成
