title: python3中await和yield from对比
date: '2019-08-22 10:15:44'
updated: '2019-08-22 10:15:44'
tags: [python]
permalink: /articles/2019/11/19/1574152035237.html
---
await和yield区别

await表达式基本上与yield from相同但只能接受awaitable对象（普通迭代器不行），awaitable 对象要么是一个协程要么是一个定义了__await__()方法的对象 



一个直观的例子
``` python
    # 这样的不行的
    async def a():
        await [1,2,3,4,5]
      
    # 这样的就可以
    def b():
        yield from [1,2,3,4,5,6]
        
    # 这样也可以
    async def c(session,url):
        async with session.get(url) as response:
            return await response.text(encoding='gb18030')

```

而async定义的函数要么包含return语句 – 包括所有Python函数缺省的return None – 和/或者 await表达式（yield表达式不行）





【参考】

[1] [https://juejin.im/entry/56ea295ed342d300546e1e22](https://juejin.im/entry/56ea295ed342d300546e1e22)

