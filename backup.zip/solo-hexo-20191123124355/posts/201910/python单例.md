title: python单例
date: '2019-10-10 17:40:56'
updated: '2019-10-10 17:40:56'
tags: [python]
permalink: /articles/2019/11/19/1574152351628.html
---
1. 简单的例子

``` python
class Singleton(object):
	_instance={}
	
	def __new__(cls,*args,**kwargs):
	    if not cls._instance:
	        cls._instance=object.__new__(cls)
	    return cls.__instance
	def __init__(self,name):
	    self._name=name

if __name__=='__main__':
    a=Singleton('Tom')
    b=Singleton('Jerry')
    c=Singleton('jack')

    print(a)
    print(b)
    print(c)

```
```plain
<__main__.Singleton object at 0x10a5cf3c8>
<__main__.Singleton object at 0x10a5cf3c8>
<__main__.Singleton object at 0x10a5cf3c8>
```
通过结果可以看到，打印出的a,b,c的内存地址是一样的，说明在内存中，这个类只实例化了一次
```
a.name='张三'
print(a.name)
print(b.name)
print(c.name)
```
结果发现a,b,c的name属性都是"张三"

2. 多线程的情况下

```
class Singleton(object):
	_instance={}
	
	def __new__(cls,*args,**kwargs):
	    if not cls._instance:
                import time
                time.sleep(1)
	        cls._instance=object.__new__(cls)
	    return cls.__instance
	def __init__(self,name):
	    self._name=name
def worker(name):
    a=Singleton(name)
    print(a)

import threading

if __name__=="__main__":
    for i in range(10):
        t=threading.Thread(target=worker,args=(i,))
        t.start()
```
```
<__main__.Singleton object at 0x101eb63c8>
<__main__.Singleton object at 0x101f55438>
<__main__.Singleton object at 0x101f55470>
<__main__.Singleton object at 0x101f38b00>
<__main__.Singleton object at 0x101f38c50>
<__main__.Singleton object at 0x101f38b00>
<__main__.Singleton object at 0x101f38cc0>
<__main__.Singleton object at 0x101f389b0>
<__main__.Singleton object at 0x101ec8898>
<__main__.Singleton object at 0x101ec8a58>
```
结果发现内存地址不一样了，说明类被多次初始化了
所以需要加把锁，保证单例的唯一性

``` python
import threading
import time
class Singleton(object):
    _instance={}
    _lock=threading.Lock()
    def __new__(cls,*args,**kwargs):
        cls._lock.acquire()
        if not cls._instance:
            time.sleep(1)
            cls._instance=object.__new__(cls)
        cls._lock.release()
        return cls._instance
    def __init__(self,name):
        self._name=name

def worker(name):
    a=Singleton(name)
    print(a)

if __name__=='__main__':
    for i in range(10):
        t=threading.Thread(target=worker,args=(i,))
        t.start()
        
```

``` plain
<__main__.Singleton object at 0x105892400>
<__main__.Singleton object at 0x105892400>
<__main__.Singleton object at 0x105892400>
<__main__.Singleton object at 0x105892400>
<__main__.Singleton object at 0x105892400>
<__main__.Singleton object at 0x105892400>
<__main__.Singleton object at 0x105892400>
<__main__.Singleton object at 0x105892400>
<__main__.Singleton object at 0x105892400>
<__main__.Singleton object at 0x105892400>
```
看得出，现在的内存地址又唯一了




