title: pyppeteer的chromium被识别出navigator.webdriver的问题
date: '2019-06-24 14:21:10'
updated: '2019-06-24 14:21:10'
tags: [pyppeteer]
permalink: /articles/2019/11/19/1574152265239.html
---
由于现在大部分网站都会检测到selenium是爬虫(总之不是正常用户)，然后试了下puppeteer和pyppeteer，一般的网站这俩货都可以成功绕过，但是有一些(某数为例)是可以检测出的，这俩用到的Chromium和本身正常的Chrome相似却又有区别，Chromium天生带有一些他独有的特征，看了一些解决的办法，都是执行js脚本修改navigator的属性，这样实际是不行的，至少我这边看的没有成功，比如
```python
import asyncio
from common.pyppeteer import launch

js1 = '''() =>{
    
           Object.defineProperties(navigator,{
             webdriver:{
               get: () => undefined
             }
           })
        }'''

js2 = '''() => {
        alert (
            window.navigator.webdriver
        )
    }'''

js3 = '''() => {
        window.navigator.chrome = {
    runtime: {},
    // etc.
  };
    }'''

js4 = '''() =>{
Object.defineProperty(navigator, 'languages', {
      get: () => ['en-US', 'en']
    });
}'''

js5 = '''() =>{
Object.defineProperty(navigator, 'plugins', {
    get: () => [1, 2, 3, 4, 5,6],
  });
}'''

await page.evaluate(js1)
await page.evaluate(js2)
await page.evaluate(js3)
await page.evaluate(js4)
...
```

这样虽然通过 
`window.navigator.webdriver`

可以看到改过来了，但是用
`"webdriver" in navigator`
检测还是会检测出来
后来找到一个方法  [https://segmentfault.com/a/1190000019539509](https://segmentfault.com/a/1190000019539509) 

添加参数 `{ignoreDefaultArgs: ["--enable-automation"]}`

```python
const browser = await puppeteer.launch({ignoreDefaultArgs: ["--enable-automation"]});
```
这时，Chromium可能会提示
> 缺少Google API 密钥，因此 Chromium 的部分功能将无法使用

这个问题的官方解决办法可以在Google官网找到 
[https://www.chromium.org/developers/how-tos/api-keys](https://www.chromium.org/developers/how-tos/api-keys)

这里由于我的chromium路径问题，始终没有解决，但是加完这个参数后的浏览器，确实可以打开之前被识别的网页了。

