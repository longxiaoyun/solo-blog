title: python反转字符串、数字
date: '2019-10-14 15:04:43'
updated: '2019-10-14 15:04:43'
tags: [python]
permalink: /articles/2019/11/19/1574152299402.html
---
``` python
def reverse(s):
    if isinstance(s,str):
        return s[::-1]
    if isinstance(s,int):
        s=str(s)
        if '-' in s:
            return '-'+s[1:][::-1]
        else:
            return s[::-1]
```
