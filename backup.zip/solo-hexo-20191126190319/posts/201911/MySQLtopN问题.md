title: MySQL top-N问题
date: '2019-11-26 14:43:18'
updated: '2019-11-26 14:44:09'
tags: [mysql, 笔记]
permalink: /articles/2019/11/26/1574750598876.html
---
MySQL的窗口函数在8.0才支持，在这之前，要实现top-n功能，比较费事，如果支持窗口函数的话，可以简单用row_number rank   dense_rank函数实现，比如说在hive sql里

```SQL
select name,salary,department
rank() over(partition by department order by salary) as rk1,
row_number() over(partition by department order by salary) as rk2,
dense_rank() over(partition by department order by salary) as rk3
from emplayee
```
或者
```SQL
select empNum,publishDate,caseCode,
count(caseCode) over(partition by empNum order by publishDate) as cnt,
rank() over(partition by empNum order by publishDate) as rk1,
row_number() over(partition by empNum order by publishDate) as rk2,
dense_rank() over(partition by empNum order by publishDate) as rk3,
first_value(caseCode) over(partition by empNum order by publishDate) as top1,
last_value(caseCode) over(partition by empNum order by publishDate) as last1 
 from  employee_history where caseCode is not null
```
结果：
![屏幕快照20191126下午2.31.15.png](https://img.hacpai.com/file/2019/11/屏幕快照20191126下午2.31.15-12946d00.png)


但是在MySQL8.0之前呢，实现这个功能的一个办法
```SQL
select DepartmentId,salary,name,ranking,depId from (
	select DepartmentId,salary,name,
	if(@dep=DepartmentId,@rank:=@rank+1,@rank:=1) as ranking,
	@dep:=DepartmentId as depId from 
	(select DepartmentId,salary,name from Emplyee order by DepartmentId,salary desc) t1,(select @cid:=null,@rank:=0) t2 
) t3 where ranking<4
```
这样可以得出top-n来
