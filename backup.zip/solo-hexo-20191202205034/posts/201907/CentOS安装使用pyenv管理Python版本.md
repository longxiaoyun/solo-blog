title: CentOS安装使用pyenv管理Python版本
date: '2019-07-16 13:57:17'
updated: '2019-07-16 13:57:17'
tags: [python]
permalink: /articles/2019/11/19/1574152604596.html
---
>服务器上一直使用的是python2.7，最近有项目需要用到Python3.5+，所以需要给某个单独的项目设置环境成python3,系统python环境目前还不好切换(依赖太多)，就是用pyenv来实现吧

一.安装
安装参考 [https://github.com/pyenv/pyenv-installer](https://github.com/pyenv/pyenv-installer)

`curl -L https://github.com/pyenv/pyenv-installer/raw/master/bin/pyenv-installer | bash`

二.使用
使用`pyenv`命令可以看到他的很多可使用参数

- 查看当前python版本
`pyenv version`
- 查看所有通过pyenv已安装python版本`pyenv versions`

- 安装一个3.6.6版本的python
`pyenv install 3.6.6`

>如果出现Build fail错误就执行下 
```shell
sudo yum install gcc zlib-devel bzip2 bzip2-devel readline-devel sqlite sqlite-devel openssl-devel tk-devel libffi-devel
```
参考[https://github.com/pyenv/pyenv/wiki](https://github.com/pyenv/pyenv/wiki)


- 设置python版本
``` shell
# 对所有的Shell全局有效，会把版本号写入到~/.pyenv/version文件中
pyenv global 3.6.3

# 只对当前目录有效，会在当前目录创建.python-version文件
pyenv local 3.6.3

# 只在当前会话有效
pyenv shell 3.6.3

# 可通过配置PYENV_VERSION环境变量或编辑~/.python-version文件设置会话默认使用的python版本
echo "3.6.3" > ~/.python-version
# or
echo 'export PYENV_VERSION="3.6.3"' >> ~/.zshrc && source ~/.zshrc
```

- 我们创建一个目标文件夹 `mkdir py3hub` 

然后
``` python
cd py3hub
pyenv local 3.6.6
```

- 重置版本

``` shell
pyenv shell --unset
pyenv local --unset
```

- 卸载(移除)版本
``` shell
pyenv uninstall 3.6.3
```
