title: mac安装使用rabbitmq
date: '2019-07-11 16:00:38'
updated: '2019-07-11 16:00:38'
tags: [rabbitmq]
permalink: /articles/2019/11/19/1574152540880.html
---

1.安装
`brew install erlang`

`brew install rabbitmq`

默认安装在目录 `/usr/local/Cellar/rabbitmq/3.7.7_1/`

```
   cd /usr/local/Cellar/rabbitmq/3.7.7_1/
   // 启用rabbitmq management插件
   sudo sbin/rabbitmq-plugins enable rabbitmq_management
```

2.配置
```
 vi ~/.bash_profile
 //加入以下两行
 export RABBIT_HOME=/usr/local/Cellar/rabbitmq/3.7.7_1
 PATH=$PATH:$RABBIT_HOME/sbin
 export PATH
 // 立即生效
 source ~/.bash_profile
```

3.启动
`rabbitmq-server`

其他命令
```
  // 后台启动
  rabbitmq-server -detached  
  // 查看状态
  rabbitmqctl status 
  // 访问可视化监控插件的界面
  // 浏览器内输入 http://localhost:15672,默认的用户名密码都是guest,登录后可以在 
  Admin那一列菜单内添加自己的用户
  rabbitmqctl stop 关闭
```

[参考][https://www.jianshu.com/p/60c358235705](https://www.jianshu.com/p/60c358235705)
