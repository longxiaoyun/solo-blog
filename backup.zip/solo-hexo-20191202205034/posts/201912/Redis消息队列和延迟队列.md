title: Redis消息队列和延迟队列
date: '2019-12-02 18:15:54'
updated: '2019-12-02 20:31:47'
tags: [Redis, 笔记]
permalink: /articles/2019/12/02/1575281754844.html
---
![](https://img.hacpai.com/bing/20190716.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> 二黑和二狗在田垄上挖鱼腥草，忽然瞥见一只兔子闪过，伸起腰来再定神时，茫茫一篇田野，兔子早已不知去向，夕阳软绵绵的在山头做最后的挣扎，像个将要从锅边滑下的糖心单



1. 异步消息队列
异步消息队列一般小型项目里我常用Redis，主要是因为懒，懒得配置RabbitMQ或者RocketMQ或者kafka，用Redis开箱即用确实比较方便。
使用队列的目的很多时候是用来做异步、解耦、或者高并发时的削峰
比如异步，在爬虫等网络、IO密集型项目里用到很多

从简单的队列开始，Redis主要利用List的`lpush,lpop,rpush,rpop`以及`blpop,brpop`来实现队列的入队和出队
简单示意图
![Azure2.jpg](https://img.hacpai.com/file/2019/12/Azure2-b03bcb30.jpg)

a. `lpush、rpop`和`rpush、lpop`
`lpush`和`rpush`是入队
`rpop`和`lpop`是出队

当队列为空时，pop将会一直循环，又取不到数据，浪费资源，一般要么加上sleep等待

b. `blpop`、`brpop`
这几个命令和上面的区别是，当队列为空时，会自动阻塞(如果超时时间设置为0的话，就回一直阻塞)直到队列中有新的值加入

```python
import redis


rconn=redis.StrictRedis(host='localhost',port=6379)

def test():
    rconn.lpush('q', 1, 2, 3, 4, 5, 6)
    while True:

        qr=rconn.rpop('q')

        print(qr)




if __name__=='__main__':

    test()
```
结果
![屏幕快照20191202下午4.52.31.png](https://img.hacpai.com/file/2019/12/屏幕快照20191202下午4.52.31-5275cbbf.png)


pop在队列为空的时候不会阻塞，一直循环，严重影响性能(飙升CPU占用，拉高redis的QPS)，因此，可以加上sleep后，判断为空等待
``` python
import redis
import time


rconn=redis.StrictRedis(host='localhost',port=6379)

def test():
    rconn.lpush('q', 1, 2, 3, 4, 5, 6)
    while True:
        qr=rconn.rpop('q')
        print(qr)
        if not qr:
            time.sleep(10)
if __name__=='__main__':

    test()
```
这样看起来是可控了，当队列为空的时候，自行sleep10秒，但是如果对于队列实时要求高的话，这里可能会导致队列的延迟，比方说当队列为空的时候，我设置等待了180秒，但是过了20秒后就又数据入队了，此时却还需要等待160秒才会出队

而如果用blpop/brpop

```
import redis
import time


rconn=redis.StrictRedis(host='localhost',port=6379)

def test():
    rconn.lpush('q', 1, 2, 3, 4, 5, 6)
    while True:
        qr=rconn.brpop('q')
        if qr:
            print(qr)
if __name__=='__main__':

    test()
```
他会自动阻塞，当有新的数据push的时候，会继续pop
> 空闲连接问题：brpop\blpop有时候会假死，即队列没有数据的时候brpop\blpop就阻塞住等待新数据，但是当新数据入队后却没有唤醒brpop\blpop起来工作，这一般是因为Redis服务端会自己关掉这种空闲连接，节约资源，所以就出现了假死问题，在获取队列的时候捕捉异常，然后重试来解决

可以由此构建多个生产者和多个消费者的生产者-消费者模型
![Azure4.jpg](https://img.hacpai.com/file/2019/12/Azure4-d4d20d93.jpg)


c. Pub/Sub(发布与订阅)

>发送者无须知道任何关于订阅者的信息， 而订阅者也无须知道是那个客户端给它发送信息， 它只要关注自己感兴趣的频道即可。




![Azure3.jpg](https://img.hacpai.com/file/2019/12/Azure3-e99d154c.jpg)

发布订阅模式，李四和王五只用订阅自己感兴趣的内容，张三发布消息的时候，按照channel来发即可。

```
import redis
import time
import multiprocessing

rconn=redis.StrictRedis(host='localhost',port=6379)

def lisi():
    sub=rconn.pubsub()
    # 李四订阅自己感兴趣的频道
    sub.subscribe('channel-1')
    for j in sub.listen():
        if j['type']=='message':
            print('我是李四，我订阅的消息是:%s' % j['data'].decode('utf-8'))


def wangwu():
    sub = rconn.pubsub()
    # 王五订阅自己感兴趣的频道
    sub.subscribe('channel-2')
    for i in sub.listen():
        if i['type']=='message':
            print('我是王五，我收到了订阅的消息:%s' % i['data'].decode('utf-8'))


def zhangsan():
    for i in range(1,10):
        rconn.publish('channel-1','发给channel-1频道的消息，呼叫二狗，呼叫二狗，收到请打二黑%d下' % i)
        rconn.publish('channel-2','发给channel-2频道的消息，收到请静默%d秒' % i)
        time.sleep(1)

if __name__=='__main__':

    multiprocessing.Process(target=zhangsan, args=()).start()
    multiprocessing.Process(target=lisi,args=()).start()
    multiprocessing.Process(target=wangwu,args=()).start()

```
![Azure5.jpg](https://img.hacpai.com/file/2019/12/Azure5-8141723d.jpg)




2. 延迟队列 
如果遇到3天后发送邮件给某些客户，或者7天后自动发布评论这样的场景，就需要使用延迟队列来操作
redis提供的zset可以实现这些功能

```
import redis
import json
import time
import uuid

pool = redis.ConnectionPool(host='localhost', port=6379)
rconn = redis.StrictRedis(connection_pool=pool)

def delay(delay_seconds=300):
    msg=json.dumps({'uuid': str(uuid.uuid4())})

    due_time = int(time.time() + delay_seconds) * 100
    print(due_time)

    rconn.zadd('delay_quque',mapping={msg:due_time})

    # 如果时间没到，数据为空

    # 获取

    '''
    注意，在3.0以前，原先的zadd方法是 zadd(name,value,score)
    在3.0以后，这个方法有点变化，变成了 zadd(name,mapping={data:score})
    获取的时候还是 zrangebyscore(name,min,max,start,num)  分别是，对应的key名称，值的范围，从那里开始取，取几个
    
    '''
    results=rconn.zrangebyscore('delay_quque',min=0,max=int(time.time()),start=0,num=1)

    
    if len(results)>0:
        # 说明有延迟任务可以执行了
        for result in results:
            # 获取分数看看
            score=rconn.zscore('delay_quque',result)
            print(score)

            del_flag=rconn.zrem('delay_quque',result)

            if del_flag:
                '''
                开始正经执行延迟任务
                '''
                data=json.loads(result)
                print(data)



if __name__=='__main__':

    delay()
```


举个例子说下这里的思想，延迟任务在当前时间的基础上，加上将要在未来某一段时间要执行的时间间隔(秒或者毫秒或者其他自己可设置)，假如说设置的这个值最终是100 也就是这个将要在未来100单位后执行的数据的分数是100，接着在循环执行 zrangebyscore ,按照上面的说法，如果最终值100不在 0-当前时间内，那么zrangebyscore的返回值当然是空，反之有值的话，就说明这个任务到期了可以执行


简单的延迟任务因此可以实现



