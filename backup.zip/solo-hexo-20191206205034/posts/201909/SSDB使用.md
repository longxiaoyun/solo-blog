title: SSDB使用
date: '2019-09-24 15:07:17'
updated: '2019-09-24 15:07:17'
tags: [Redis, ssdb]
permalink: /articles/2019/11/19/1574152091664.html
---

特性

- 替代 Redis 数据库, Redis 的 100 倍容量
- LevelDB 网络支持, 使用 C/C++ 开发
- Redis API 兼容, 支持 Redis 客户端
- 适合存储集合数据, 如 list, hash, zset...
- 客户端 API 支持的语言包括: C++, PHP, Python, Java, Go
- 持久化的队列服务
- 主从复制, 负载均衡





安装
```shell
    wget --no-check-certificate https://github.com/ideawu/ssdb/archive/master.zip
    unzip master
    cd ssdb-master
    make
    sudo make install
```


操作
```shell
    # 启动
    ./ssdb-server ssdb.conf
    
    # 后台启动
    ./ssdb-server -d ssdb.conf
    
    # 停止
    ./ssdb-server ssdb.conf -s stop
    
    # 重启
    ./ssdb-server ssdb.conf -s restart
```


日志

ssdb的日志占用硬盘特别大，要么定时任务定期删除，要么把日志层级改为error(默认层级是debug),正常的操作信息就不要写入日志了
```shell
    vim ssdb.conf
    
    # 修改
    logger:
            level: debug
            output: log.txt
            rotate:
            		# 这里会把日志文件切分成1000MB一个，但是并不会自己删除，还是需要手动去定期删除下
                    size: 1000000000
    # 为
    logger:
            level: error
            output: log.txt
            rotate:
                    size: 1000000000
    
    
    # 可以修改的日志层级:debug, info, warn, error, fatal
```




====

ssdb可视化工具

安装
```shell
    git clone https://github.com/jhao104/SSDBAdmin.git
    
    cd SSDBAdmin
    
    # 编辑SSDBAdmin/setting.py，修改数据库地址和端口及SSDBAdmin地址及端口
    
    # 安装依赖
    pip install -r requirements.txt
```


启动
```shell
python3 run.py
```


访问
```
http://127.0.0.1:5000/ssdbadmin
```





【参考】
[1] [http://ssdb.io/zh_cn/](http://ssdb.io/zh_cn/)

[2] [https://github.com/jhao104/SSDBAdmin](https://github.com/jhao104/SSDBAdmin)

[3] [https://github.com/ideawu/ssdb/issues/698](https://github.com/ideawu/ssdb/issues/698)

[4] [http://ssdb.io/docs/config.html](http://ssdb.io/docs/config.html)

