title: Cython简单测试
date: '2019-10-15 11:34:19'
updated: '2019-10-15 11:34:19'
tags: [python]
permalink: /articles/2019/11/19/1574152647858.html
---
1. 新建一个helloworld.pyx文件
``` python
  5 class HW(object):
  6     def __init__(self):
  7         self.name='测试'
  8     def show(self):
  9         print('hello world!')
 10     def compute(self):
 11         return 1+8
 12 
 13 
 14 
 15 hw=HW()
```


2. 新建一个setup.py文件
``` python
from distutils.core import setup
from Cython.Build import cythonize

setup(
    ext_modules = cythonize("helloworld.pyx")
)
```


3. 终端命令编译之
``` shell
python setup.py build_ext --inplace
```


4. 调用
``` shell
vim test.py

from helloworld import HW

hw=HW()

hw.show()

print(hw.compute())

```








