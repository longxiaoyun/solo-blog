title: 一种Flask项目目录结构
date: '2019-08-23 17:31:12'
updated: '2019-08-23 17:31:12'
tags: [python]
permalink: /articles/2019/11/19/1574152137072.html
---
``` python
|-Project

	|-app/

		|-templates/

		|-static/

		|-main/

			|-init.py
			|-errors.py
			|-forms.py
			|-views.py
        |-__init__.py
        |-email.py
        |-models.py
    |-migrations.py/
    |-tests/
    	|-__init__.py
    	|-test*.py
   	|-venv/
   	|-requirements.txt
   	|-config.py
   	|-manage.py
	
文件夹:
migrations 包含数据库迁移脚本
tests 单元测试
venv 虚拟环境
app 存放程序所有代码、静态文件等
文件:
requirements.txt 项目依赖
config.py 配置文件
manage.py 启动程序


```
