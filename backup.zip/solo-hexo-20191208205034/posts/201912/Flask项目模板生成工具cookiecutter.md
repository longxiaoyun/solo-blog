title: Flask项目模板生成工具cookiecutter
date: '2019-12-06 10:49:31'
updated: '2019-12-06 10:49:31'
tags: [笔记]
permalink: /articles/2019/12/06/1575600571356.html
---
找到一个可以生成Flask项目结构的模板工具
https://github.com/cookiecutter-flask/cookiecutter-flask

 需要python3.6+，可以用docker或者pip安装

- pip方式
1. 安装
`pip install  cookiecutter`
2. 生成模板
`cookiecutter https://github.com/cookiecutter-flask/cookiecutter-flask.git`

这个过程要好久


- docker方式(推荐)
下载项目 
```
git clone https://github.com/cookiecutter-flask/cookiecutter-flask.git

cd cookiecutter-flask 

./cookiecutter-docker.sh
# full_name [Steven Loria]: 全名
# email [sloria1@gmail.com]: 邮箱
# github_username [sloria]: github用户名
# project_name [My Flask App]: 项目名称
# app_name [xiaoyun_blog_core]: app名称
# project_short_description [A flasky app.]: 项目描述
# Select use_pipenv: 是否使用pipenv虚拟环境
# Select python_version: 选择python版本
# Select node_version: 选择node版本
# Select use_heroku: 是否使用hreoku云平台

done

```
3. 配置和运行
在生成的文件夹里有readme.md，里边有详细的启动部署步骤
