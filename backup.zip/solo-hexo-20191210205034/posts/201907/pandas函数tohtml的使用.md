title: pandas函数to_html的使用
date: '2019-07-25 13:46:02'
updated: '2019-07-25 13:46:02'
tags: [python, pandas]
permalink: /articles/2019/11/19/1574151971054.html
---
[](https://)[](https://)[](https://)使用django上传一份Excel或者csv文件，并希望在页面显示上传的数据表，用pandas的to_html函数可以实现
首先前端页面
```html
          <form method="POST" enctype="multipart/form-data" >
                {% csrf_token %}
                <input id="myfile" type="file" name="test_ids" />
                <input type="button" id="sub" value="上传" />
          </form>


          <div id="showtable" class="table-responsive" style="margin-top:30px;">
              {% autoescape off %}
                   {{ html_table }}
              {% endautoescape %}
          </div>


<script>
    $('#sub').click(function () {
        var formData = new FormData();

        var file_info = document.getElementById("myfile").files[0];

        formData.append('test_ids', file_info);

        if (file_info == undefined) {
            alert("你没有选择任何文件");
            return false;
        }
        $.ajax({
            url: "/file_upload/",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (data) {
                var showDiv=document.getElementById('showtable')
                showDiv.innerHTML=''
                showDiv.innerHTML +=data.data
            }
        })
    });



</script>
```
然后在django服务端
```python


# Create your views here.

from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import pandas as pd


from django.http import JsonResponse


def index(request):
    return render(request,'index.html')

@csrf_exempt
def file_upload(request):
    f = request.FILES['shixin_ids']

    col= request.POST.get('col',0)
    sheet=request.POST.get('sheet',0)

    print("col:%s" % col)
    print("sheet:%s" % sheet)

    if f:
        type_file = f.name.split('.')[1]

        if type_file == ('xlsx' or 'xls'):
            df = pd.read_excel(f, encoding="utf-8")

            headers_list=df.columns.values.tolist()

            html_table = df[:10].to_html(index=False,classes='table table-hover table-sm')

            return JsonResponse({"data": html_table})

            # return render(request, 'index.html', {'html_table': html_table})

        elif type_file == 'csv':  # csv
            df = pd.read_csv(f, encoding="utf-8")

            html_table = df[:10].to_html(index=False,classes='table table-hover table-sm',table_id='11')

            headers_list = df.columns.values.tolist()

            return JsonResponse({"data": html_table})

            # get请求时
            # return render(request, 'index.html', {'html_table': html_table})
        else:
            return JsonResponse({"data":"文件格式不合法"})


# 异步处理文件
def handler_file_to_db(id_list):
    pass

```






[参考]
https://pandas.pydata.org/pandas-docs/version/0.19.0/generated/pandas.DataFrame.to_html.html
