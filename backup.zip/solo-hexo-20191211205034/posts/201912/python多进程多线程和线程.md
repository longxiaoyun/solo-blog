title: python多进程、多线程和线程
date: '2019-12-10 11:31:33'
updated: '2019-12-10 11:31:33'
tags: [笔记, python]
permalink: /articles/2019/12/10/1575948693418.html
---



#### 一. 多进程、多线程、协程

##### 多进程

1. 进程是系统资源分配的最小单元，一个运行中的程序就可以说是一个进程，它具有独立的空间、内存、数据栈等资源

##### 多线程

1. 线程是操作系统调度的最小单元，他是依赖于进程存在的，一个进程至少有一个线程，也就是主线程，也可以有多个多线程，在一个进程中多个线程共享资源和内存等，在python中，一般的编译器使用Cython,这样就会有一个GIL锁的存在，导致多线程在这里会同步执行，同一时间只能有一个线程获得GIL锁，而只有获得GIL锁的线程才能执行，实际上在一个进程里，多个线程是一定没有办法并行的，多个线程是按照一定的顺序交替执行的
2. GIL锁一般在遇到IO密集型任务时，如果cpu被闲置等待，此时就会释放GIL锁；亦或者计数器(默认满100)达到设定的值后，释放GIL锁，GIL锁释放以后，其他线程就可以竞争锁了；但是如果是计算密集型任务，多线程没有办法利用多核，此时用多进程是个好的选择，所以说，在遇到IO密集型任务时，用多线程其实也不错，比如说爬虫之类，并不是一点用都没有的鸡肋(因为用多进程的开销要比用多线程的开销小)，遇到计算密集型任务就用多进程
3. 对于有时候确实不想用GIL锁，可以换一个编译器 比如说Jython,或者用多进程的时候，把多进程这部分代码用C来编写

> 过于这个锁，我了解当时创建python时，只考虑了单核机器多线程间的资源竞争，为了保证资源一致性，就需要加锁，而越细粒度的锁就越容易出错且还会降低性能，所以就索性加了一把大锁，也就是GIL,到现在没有什么好的办法在去掉这个锁的情况下，依然保证python的特性，所以就还留着

##### 协程

1. 协程是比线程更细粒度的例程，最大的特点是用户可以控制，比如说在执行a函数的时候，执行一半可以挂起然后去执行函数b，函数b执行一半后再挂起接着回去执行函数a,整个过程的调度都是用户自己可控的，而且因为没有线程的切换(协程是在同一个线程里的)，所以他的效率比线程要高；python里边，在py3.4之后，自己实现了协程，通过asyncio调用，基础其实是基于生成器generator实现的，主要是yield关键字和yield from  具体可以了解

    https://juejin.im/post/5c13245ee51d455fa5451f33

   在py3.4之前，实现协程一般使用gevent等三方库，对于IO密集型的任务，一般使用协程会很不错，开销最小，计算密集型的使用多进程+协程的方式

   

#### 二.进程间通信

##### python 进程间通信

1. python 进程间通信有两种方式

   a. queue

   ​	队列的方式，创建一个对队列，一个进程写入数据到队列，另一个进程从队列读取数据

   ``` python
   
   from multiprocessing import Queue
   from multiprocessing import Process
   
   def put_data(q):
       q.send('Hello Worlld')
   
       
       
    if __name__=='__main__':
       q=Queue()
       
       p1=Process(target=put_data,args=q,)
       p1.start()
       
       
       
       res=q.get()
       print("获取数据:%s" % res)
       
       p1.join()
       
   ```

   

   

   b. pipe

   ​	新建一个管道，他的两端可以连接了两个进程，其中任一端口连接后都可以读写数据，这样，就可以传输数据了。

   ​	管道通过`multiprocessing.Pipe()` 创建，返回一个PipeConnect对象，这个对象有两个端口，用于连接两个进程，PipeConnect对象具有的方法包括

   ​	send()  从一个端口发送数据，两个限制，必须是可序列化的pipkle，大小必须小于32MB,

   ​	recv()  从一个端口接收数据

   ​	send_bytes()   发送buffer字节数据，可以指定offset和size，不指定就默认发送全部

   ​	recv_bytes() 或者recv_ytes_into()  接收字节数据，后者是接收后放到buffer里

   

   

   ``` python 
   from multiprocessing import Pipe
   from multiprocessing imprt Process
   
   def put_data(p):
       p.send('hello')
   if __name__=="__main__":
       p=Pipe()
       
       t1=Process(target=put_data,args=(p,))
       
       t1.start()
       
       res=p.recv()
       
       print("收到的数据:%s" % res)
       
       t1.join()
       
       
   ```

   

   
