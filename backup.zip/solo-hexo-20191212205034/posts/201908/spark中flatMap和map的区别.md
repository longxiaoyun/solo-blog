title: spark中flatMap和map的区别
date: '2019-08-20 14:09:56'
updated: '2019-08-20 14:09:56'
tags: [spark]
permalink: /articles/2019/11/19/1574152686800.html
---
![](https://img.hacpai.com/bing/20190408.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


>map:将原数据的每个元素传给函数func进行格式化，返回一个新的RDD

>flatMap:flatMap会将一个长度为n的RDD转换成一个n个元素的集合，然后再把这n个元素合成到一个单个RDD的结果集，及"先映射后扁平化"，第一步和map一样，完成第一步后再把所有元素合并成一个对象
```python
tokenize("coffe panda")=List("coffee","panda")

rdd1

{"coffee panda","happy panda","happiest panda party"}
```

```python
rdd1.map(tokenize):

{["coffee","panda"],["happy","panda"],["happiest","panda","party"]}
```

```python
rdd1.flatMap(tokenize):

{"coffee","panda","happy","panda","happiest","panda","party"}
```
