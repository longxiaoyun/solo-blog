title: springboot redis客户端jedis和lettuce问题笔记
date: '2019-12-03 16:34:27'
updated: '2019-12-03 16:34:27'
tags: [笔记, Redis, java]
permalink: /articles/2019/12/03/1575362067513.html
---
在springboot 2.x以后，`spring-boot-starter-data-redis`默认使用的客户端是`lettuce`,它依赖`commons-pool2`，如果只引入`spring-boot-starter-data-redis`很可能会报错

```
Error creating bean with name 'redisTemplate' defined in class path resource [org/springframework/boot/autoconfigure/data/redis/RedisAutoConfiguration.class]: Unsatisfied dependency expressed through method 'redisTemplate' parameter 0; nested exception is org.springframework.beans.factory.BeanCreationException: Error creating bean with name 'redisConnectionFactory' defined in class path resource [org/springframework/boot/autoconfigure/data/redis/LettuceConnectionConfiguration.class]: Bean instantiation via factory method failed; nested exception is org.springframework.beans.BeanInstantiationException: Failed to instantiate [org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory]: Factory method 'redisConnectionFactory' threw exception; nested exception is java.lang.NoClassDefFoundError: org/apache/commons/pool2/impl/GenericObjectPoolConfig
2019-12-03 16:18:07.512  INFO 64670 --- [           main] o.apache.catalina.core.StandardService   : Stopping service [Tomcat]
```

所以如果在使用默认redis客户端时，pom文件应当加上
``` xml
<dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>

<dependency>
	<groupId>org.apache.commons</groupId>
	<artifactId>commons-pool2</artifactId>
</dependency>
```

`application.propertities`配置文件
```
# Redis数据库（默认为0）
spring.redis.database=0
# Redis服务器地址
spring.redis.host=127.0.0.1
# Redis服务器连接端口
spring.redis.port=6379
# Redis服务器连接密码（默认为空）
spring.redis.password=
#连接池最大连接数（使用负值表示没有限制）
spring.redis.lettuce.pool.max-active=8
# 连接池最大阻塞等待时间（使用负值表示没有限制）
spring.redis.lettuce.pool.max-wait=-1
# 连接池中的最大空闲连接
spring.redis.lettuce.pool.max-idle=8
# 连接池中的最小空闲连接
spring.redis.lettuce.pool.min-idle=0
# 连接超时时间（毫秒）
spring.redis.timeout=0
```

改为jedis客户端也简单，把pom文件改成
```
<dependency> 
	<groupId>org.springframework.boot</groupId> 
	<artifactId>spring-boot-starter-data-redis</artifactId> 
	<exclusions> 
		<exclusion> 
			<groupId>io.lettuce</groupId> 
			<artifactId>lettuce-core</artifactId> 
		</exclusion> 
	</exclusions> 
</dependency>

<dependency>  
	<groupId>redis.clients</groupId>  
	<artifactId>jedis</artifactId>  
</dependency>

```

配置文件改为
```
# Redis数据库索引（默认为0）
spring.redis.database=0
# Redis服务器地址
spring.redis.host=127.0.0.1
# Redis服务器连接端口
spring.redis.port=6379
# Redis服务器连接密码（默认为空）
spring.redis.password=
#连接池最大连接数（使用负值表示没有限制）
spring.redis.jedis.pool.max-active=9
# 连接池最大阻塞等待时间（使用负值表示没有限制）
spring.redis.jedis.pool.max-wait=-1
# 连接池中的最大空闲连接
spring.redis.jedis.pool.max-idle=8
# 连接池中的最小空闲连接
spring.redis.jedis.pool.min-idle=0
# 连接超时时间（毫秒）
spring.redis.timeout=0
```


jedis客户端和lettuce客户端的区别
- Jedis在多线程环境是非线程安全的，除非使用连接池，为每个jedis实例增加物理连接,对redis的各种操作支持的较好
- Lettuce的连接基于Netty，在多线程环境是线程安全的，可伸缩性等，多线程环境时性能比较好
- 还有一个就是适合分布式的客户端Redisson

